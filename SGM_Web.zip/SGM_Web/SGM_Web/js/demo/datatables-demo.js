// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable({name: 'Rai', position: 'Chef', office: 'trab', age: 19, startDate: '15/08/1964', salary: 3502392.12});
});
