-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema gpm
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema gpm
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `gpm` DEFAULT CHARACTER SET utf8 ;
USE `gpm` ;

-- -----------------------------------------------------
-- Table `gpm`.`admin`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gpm`.`admin` (
  `idadmin` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(150) NOT NULL,
  `matricula` VARCHAR(10) NOT NULL,
  `senha` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`idadmin`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gpm`.`muda`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gpm`.`muda` (
  `idmuda` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(50) NOT NULL,
  `valor` FLOAT NOT NULL,
  `tipo_unitario` ENUM('ornamental', 'medicinal', 'fruteira-muda', 'nativa-muda') NOT NULL,
  `estoque_minimo` INT(11) NOT NULL,
  `estoque_atual` INT(11) NOT NULL,
  PRIMARY KEY (`idmuda`))
ENGINE = InnoDB
AUTO_INCREMENT = 2921
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gpm`.`entrada`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gpm`.`entrada` (
  `identrada` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `fornecedor` ENUM('setor de mudas', 'outros') NOT NULL,
  `data` DATETIME NOT NULL,
  `quantiade` INT(11) NOT NULL,
  `muda_idmuda` BIGINT(20) NOT NULL,
  `admin_idadmin` BIGINT(20) NOT NULL,
  PRIMARY KEY (`identrada`),
  INDEX `fk_entrada_muda_idx` (`muda_idmuda` ASC),
  INDEX `fk_entrada_admin1_idx` (`admin_idadmin` ASC),
  CONSTRAINT `fk_entrada_admin1`
    FOREIGN KEY (`admin_idadmin`)
    REFERENCES `gpm`.`admin` (`idadmin`),
  CONSTRAINT `fk_entrada_muda`
    FOREIGN KEY (`muda_idmuda`)
    REFERENCES `gpm`.`muda` (`idmuda`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gpm`.`requisicao_login`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gpm`.`requisicao_login` (
  `idrequisicao_login` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CPF` VARCHAR(14) NULL DEFAULT NULL,
  `CNPJ` VARCHAR(14) NULL DEFAULT NULL,
  `matricula` VARCHAR(10) NULL DEFAULT NULL,
  `nome` VARCHAR(150) NOT NULL,
  `senha` VARCHAR(64) NOT NULL,
  `status` ENUM('A', 'N') NOT NULL,
  `admin_idadmin` BIGINT(20) NOT NULL,
  `tipo_usuario` ENUM('usuario', 'administrador') NOT NULL DEFAULT 'usuario',
  PRIMARY KEY (`idrequisicao_login`),
  INDEX `fk_requisicao_login_admin1_idx` (`admin_idadmin` ASC),
  CONSTRAINT `fk_requisicao_login_admin1`
    FOREIGN KEY (`admin_idadmin`)
    REFERENCES `gpm`.`admin` (`idadmin`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gpm`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gpm`.`usuario` (
  `idusuario` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `CPF` VARCHAR(14) NULL DEFAULT NULL,
  `CNPJ` VARCHAR(14) NULL DEFAULT NULL,
  `matricula` VARCHAR(10) NULL DEFAULT NULL,
  `nome` VARCHAR(150) NOT NULL,
  `senha` VARCHAR(64) NOT NULL,
  `tipo_usuario` ENUM('usuario', 'administrador') NOT NULL DEFAULT 'usuario',
  PRIMARY KEY (`idusuario`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gpm`.`requisicao_muda`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gpm`.`requisicao_muda` (
  `idrequisicao_muda` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `status` ENUM('A', 'N') NOT NULL,
  `data` DATETIME NOT NULL,
  `admin_idadmin` BIGINT(20) NOT NULL,
  `muda_idmuda` BIGINT(20) NOT NULL,
  `usuario_idusuario` BIGINT(20) NOT NULL,
  `qtd_requisitada` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`idrequisicao_muda`),
  INDEX `fk_requisicao_muda_admin1_idx` (`admin_idadmin` ASC),
  INDEX `fk_requisicao_muda_muda1_idx` (`muda_idmuda` ASC),
  INDEX `fk_requisicao_muda_usuario1_idx` (`usuario_idusuario` ASC),
  CONSTRAINT `fk_requisicao_muda_admin1`
    FOREIGN KEY (`admin_idadmin`)
    REFERENCES `gpm`.`admin` (`idadmin`),
  CONSTRAINT `fk_requisicao_muda_muda1`
    FOREIGN KEY (`muda_idmuda`)
    REFERENCES `gpm`.`muda` (`idmuda`),
  CONSTRAINT `fk_requisicao_muda_usuario1`
    FOREIGN KEY (`usuario_idusuario`)
    REFERENCES `gpm`.`usuario` (`idusuario`))
ENGINE = InnoDB
AUTO_INCREMENT = 28
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gpm`.`saida`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gpm`.`saida` (
  `idsaida` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `data` DATETIME NOT NULL,
  `quantidade` INT(11) NOT NULL,
  `admin_idadmin` BIGINT(20) NOT NULL,
  `muda_idmuda` BIGINT(20) NOT NULL,
  `usuario_idusuario` BIGINT(20) NOT NULL,
  PRIMARY KEY (`idsaida`),
  INDEX `fk_saida_admin1_idx` (`admin_idadmin` ASC),
  INDEX `fk_saida_muda1_idx` (`muda_idmuda` ASC),
  INDEX `fk_saida_usuario1_idx` (`usuario_idusuario` ASC),
  CONSTRAINT `fk_saida_admin1`
    FOREIGN KEY (`admin_idadmin`)
    REFERENCES `gpm`.`admin` (`idadmin`),
  CONSTRAINT `fk_saida_muda1`
    FOREIGN KEY (`muda_idmuda`)
    REFERENCES `gpm`.`muda` (`idmuda`),
  CONSTRAINT `fk_saida_usuario1`
    FOREIGN KEY (`usuario_idusuario`)
    REFERENCES `gpm`.`usuario` (`idusuario`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
